import React from 'react';
import { Button } from '@mui/material';
import ShareIcon from '@mui/icons-material/Share';

const ShareComponent = ({ shareLink }) => {
  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink)
      .then(() => {
        alert('Link copied to clipboard!');
      })
      .catch((err) => {
        console.error('Failed to copy link: ', err);
      });
  };

  const handleShareEmail = () => {
    const subject = 'Check out this activity!';
    const body = `I found this activity and thought you might like it: ${shareLink}`;
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  return (
    <div>
      <Button variant="outlined" startIcon={<ShareIcon />} onClick={handleCopyLink}>
        Copy Link
      </Button>
      <Button variant="outlined" startIcon={<ShareIcon />} onClick={handleShareEmail}>
        Share via Email
      </Button>
    </div>
  );
};

export default ShareComponent;
