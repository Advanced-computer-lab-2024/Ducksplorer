import React from 'react'
import FormSection from '../Components/FormSection';
const Signup = () => {

  return (
    <div>
      <FormSection/>
    </div>
  )
}

export default Signup

