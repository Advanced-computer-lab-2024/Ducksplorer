import React from "react";
import AddActivityForm from "../../Components/AddActivityForm";
const AddActivity = () => {
  return (
    <div>
      <AddActivityForm />
    </div>
  );
};

export default AddActivity;
