import AdvertiserSidebar from "../../Components/Sidebars/AdvertiserSidebar";
import React from "react";

function AdvertiserDashboard() {
  return <AdvertiserSidebar />;
}

export default AdvertiserDashboard;
